# Documento de Usabilidade — Formulário de Tecnologias Emergentes

Este documento explica detalhadamente como o protótipo aplica os **Princípios da Gestalt**, as **Heurísticas de Nielsen** e os **Conceitos de Usabilidade**. Também mostra exemplos práticos dentro da interface criada.

---

## 1) Visão Geral do Protótipo

- **Tema**: Tecnologias emergentes (IA, RA, Blockchain, IoT, Robótica, Cibersegurança).  
- **Arquivos entregues**:  
  - `index.html` → estrutura e semântica  
  - `style.css` → estilo e hierarquia visual  
  - `script.js` → interatividade, validação e feedback  
  - `usabilidade.md` → documentação  
- **Tarefa do usuário**: preencher Nome e E-mail, marcar áreas de interesse e (opcionalmente) escrever um comentário, enviando o formulário.  
- **Objetivo**: demonstrar, na prática, como IHC melhora a experiência de uso.

---

## 2) Princípios da Gestalt aplicados

- **Proximidade** → campos relacionados foram agrupados em *cards* e *fieldsets* (“Dados Pessoais”, “Áreas de interesse”). Isso reduz esforço de leitura.  
- **Semelhança** → inputs, botões e checkboxes seguem mesmo estilo (bordas arredondadas, tipografia e cores consistentes), facilitando reconhecimento.  
- **Contraste** → cores fortes destacam ações:  
  - Azul/roxo → botões principais e cabeçalho  
  - Verde → sucesso  
  - Vermelho → erro  
- **Alinhamento** → grade coerente: labels acima dos campos, espaçamento padronizado.  
- **Figura/fundo** → cartões brancos com sombra se destacam sobre o fundo em gradiente, guiando o olhar do usuário.

---

## 3) Heurísticas de Nielsen aplicadas

1. **Visibilidade do status do sistema**  
   - Spinner no botão “Enviar” e mensagens em região de status com `aria-live`.  
   - Toast animado confirmando sucesso ou erro.

2. **Prevenção de erros**  
   - Validação de e-mail com regex.  
   - Campos obrigatórios (`required`) e aviso se nenhum interesse for marcado.  
   - Botão “Enviar” bloqueado durante envio.

3. **Consistência e padrões**  
   - Mesma tipografia, cores e estilos em todos os controles.  
   - Estrutura de mensagens de erro sempre abaixo do campo.

4. **Feedback ao usuário**  
   - Erros exibidos em vermelho diretamente no campo afetado.  
   - Sucesso exibido em verde, com resumo dos dados enviados.

---

## 4) Conceitos de Usabilidade aplicados

- **Facilidade de uso**  
  - Navegação por teclado (Tab/Enter).  
  - Botões claros: “Enviar” e “Limpar”.  
  - Placeholders e microcopy ajudam sem exigir memorização.

- **Estética**  
  - Fundo em gradiente moderno.  
  - Botões com gradiente e animação suave.  
  - Layout limpo e chamativo, sem poluição visual.

- **Clareza**  
  - Rótulos objetivos e exemplos: “exemplo@dominio.com”.  
  - Legendas explicando grupos de campos.

- **Acessibilidade**  
  - Uso de `fieldset`, `legend`, `label for`.  
  - `aria-live="polite"` para feedback de status.  
  - Contraste de cores e foco visível em todos os elementos.

---

## 5) Estrutura e Boas Práticas

- **Separação de responsabilidades**: HTML semântico, CSS para estilo, JS para comportamento.  
- **Design tokens** no CSS (`:root`) facilitam manutenção de cores e espaçamentos.  
- **Animações suaves** (hover, foco, toasts) aumentam feedback sem distrair.  
- **Responsividade** → layout adaptado a telas pequenas (coluna única em celulares).

---

## 6) Como testar

1. **Fluxo feliz** → preencher Nome/E-mail, marcar interesse e enviar → toast verde aparece.  
2. **Erro de e-mail** → digitar `teste@abc` → mensagem vermelha “Informe um e-mail válido”.  
3. **Nenhum interesse marcado** → tentar enviar → erro em vermelho “Selecione pelo menos uma área”.  
4. **Comentários longos** → exceder 300 caracteres → contador bloqueia automaticamente.  
5. **Teclado** → navegar com Tab/Shift+Tab e enviar com Enter.  

---

## 7) Conclusão

O protótipo demonstra como **Gestalt, Nielsen e Usabilidade** se complementam.  
- **Gestalt** organiza e guia o olhar do usuário.  
- **Nielsen** garante que o sistema seja previsível e dê feedback correto.  
- **Usabilidade** torna a experiência acessível, clara e agradável.  

O resultado é um formulário **funcional, bonito e inclusivo**, adequado para ensino de IHC e pronto para uso em demonstrações práticas.
