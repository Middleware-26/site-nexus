const form = document.getElementById('formulario');
const btnEnviar = document.getElementById('btn-enviar');
const btnLimpar = document.getElementById('btn-limpar');
const statusBox = document.getElementById('status');
const comentarios = document.getElementById('comentarios');
const contador = document.getElementById('comentarios-contador');

// Atualiza contador de caracteres
function atualizaContador() {
  const max = comentarios.getAttribute('maxlength');
  contador.textContent = `${comentarios.value.length}/${max}`;
}
comentarios.addEventListener('input', atualizaContador);
atualizaContador();

// Mostra erro
function setErro(id, msg) {
  document.getElementById(`erro-${id}`).textContent = msg || '';
}

// Validação
function validaFormulario() {
  let ok = true;

  const nome = document.getElementById('nome');
  if (nome.value.trim().length < 2) {
    setErro('nome', 'Informe um nome válido (mínimo 2 caracteres).');
    ok = false;
  } else setErro('nome', '');

  // Email
const email = document.getElementById('email');
const emailVal = email.value.trim();
const emailOk = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(emailVal);
if (!emailOk) {
  setErro('email', 'Informe um e-mail válido (ex.: exemplo@dominio.com).');
  ok = false;
} else {
  setErro('email', '');
}


  const interesses = document.querySelectorAll('input[name="interesses"]:checked');
  if (interesses.length === 0) {
    document.getElementById('erro-interesses').textContent = 'Selecione pelo menos uma área.';
    ok = false;
  } else document.getElementById('erro-interesses').textContent = '';

  return ok;
}

// Toast feedback
function toast(tipo, msg) {
  statusBox.innerHTML = `<div class="toast ${tipo}">${msg}</div>`;
}

// Envio
form.addEventListener('submit', e => {
  e.preventDefault();
  if (!validaFormulario()) {
    toast('erro', 'Verifique os campos destacados.');
    return;
  }

  toast('sucesso', 'Enviando...');
  setTimeout(() => {
    const nome = document.getElementById('nome').value.trim();
    const interesses = Array.from(document.querySelectorAll('input[name="interesses"]:checked')).map(i => i.value);
    toast('sucesso', `Obrigado, ${nome}! Você escolheu: ${interesses.join(', ')}.`);
    form.reset();
    atualizaContador();
  }, 1000);
});

// Botão limpar
btnLimpar.addEventListener('click', () => {
  ['nome','email','comentarios'].forEach(id => setErro(id, ''));
  document.getElementById('erro-interesses').textContent = '';
  statusBox.textContent = '';
  atualizaContador();
});
